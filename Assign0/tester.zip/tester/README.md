# CS 201 Test Case Program

### Used to run multiple tests at once for projects

## To Add Test Cases: 
Add your <test case>.c code file into "submission0". Your <test case>.c file should be unique in name.
Add the expected results into "expected0". The file must be .txt, and must have the same name as your <test case>.c file.

## To Use/Run:
Add your project code into assign0. You will need a specific argument in your Makefile. See Makefile within the root folder of the repository for an example.
Your program's results will show in the folder "results".
